﻿namespace CryptoTraderScanner
{
    public enum TradeType
    {
        Long,
        Short
    }
}
